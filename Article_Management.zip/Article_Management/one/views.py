from django.shortcuts import render,HttpResponseRedirect
from one.forms import Signup
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate,login,logout


from one.models import Articlemodel
from one.forms import Article_form
from django.http import HttpResponseRedirect

#-----------------------------------------------------------#

from one.models import Articlemodel
from one.forms import Article_form
from django.http import HttpResponseRedirect

# Create your views here.

def home_page(request):
    return render(request,'home.html')

def signup(request):
    if request.method=='POST':
        fm = Signup(request.POST)
        if fm.is_valid():
            messages.success(request,'account created sucssesfully')
            fm.save()
    else:
        fm = Signup()
    return render(request,'signup.html',{'form':fm})


def login_page(request):
    if not request.user.is_authenticated:
        if request.method == 'POST':
            fm = AuthenticationForm(request=request,data=request.POST)
            if fm.is_valid():
                username = fm.cleaned_data['username']
                password = fm.cleaned_data['password']
                db=authenticate(username=username,password=password)
                db.save()
                if db is not None:
                    login(request,db)
                    messages.success(request,'Updated Succssesfully')
                    return HttpResponseRedirect('/profile/')
        else:
            fm = AuthenticationForm()
            return render(request,'login.html',{'form':fm})
    else:
        return HttpResponseRedirect('/profile/')


def profile_page(request):
    if request.user.is_authenticated:
        return render(request, 'userprofile.html', {"name": request.user})
    else:
        return HttpResponseRedirect('/login/')

def logoutuser(request):
    logout(request)
    return HttpResponseRedirect('/login/')




# Create your views here.
def Crud(request):
    if request.method == 'POST':
        fm = Article_form(request.POST)
        if fm.is_valid():
            Article_name = fm.cleaned_data['Article_name']
            Article_date = fm.cleaned_data['Article_date']
            Article_writer = fm.cleaned_data['Article_writer']
            Article_reviews = fm.cleaned_data['Article_reviews']

            db = Articlemodel(Article_name=Article_name,Article_date=Article_date,Article_writer=Article_writer,Article_reviews=Article_reviews)
            db.save()
            fm = Article_form()
    else:
        fm = Article_form()
    data = Articlemodel.objects.all()
    return render(request,'index.html',{'form':fm,'fetch': data})

def update(request,id):
    if request.method == 'POST':
        pi = Articlemodel.objects.get(pk=id)
        fm = Article_form(request.POST,instance=pi)
        if fm.is_valid():
            fm.save()
            messages.info(request,'Data Updated Successfully')

    else:
        pi = Articlemodel.objects.get(pk=id)
        fm = Article_form(instance=pi)

    return render(request,'update.html',{'form':fm})

def delete(request,id):
    if request.method == 'POST':
        fm = Articlemodel.objects.get(pk=id)
        fm.delete()
        return HttpResponseRedirect('/')



